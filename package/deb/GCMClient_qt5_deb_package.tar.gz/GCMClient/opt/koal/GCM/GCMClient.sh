#!bash
set -u

cd /opt/koal/GCM
nohup ./GCMClient>/dev/null 2>&1 &
